02-10 모델 초기안 faiss-bart/bert-llm 모델 완성

랭체인 프롬트 테스트 요청(에러 검출)
